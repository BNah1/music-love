import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:musiclove/core/model/mp3_file_model.dart';
import 'package:musiclove/feature/main_shell_view.dart';
import 'package:musiclove/home_view.dart';

import '../../feature/play_music/presentation/view/play_music_view.dart';

final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');

class AppRoutes {

  ///////////////////////////////
  ////   Route names
  ///////////////////////////////

  static const String home = '/home';
  static const String playList = '/playList';
  static const String playMusic = '/playMusic';
  static const String setting = '/setting';

  // Khởi tạo GoRouter
  static final GoRouter router = GoRouter(
    initialLocation: home,
    debugLogDiagnostics: true,
    navigatorKey: rootNavigatorKey,
    errorBuilder: (context, state) => _errorRoute(state),
    routes: [
      ShellRoute(
        builder: (context, state, child) {
          return MainShellView(child: child);
        },
        routes: [
          GoRoute(
            path: home, // Dashboard
            pageBuilder: (context, state) => const CupertinoPage(child: HomeView()),
          ),
          GoRoute(
            path: playList,
            pageBuilder: (context, state) => const CupertinoPage(child: HomeView()),
          ),
          GoRoute(
            path: setting,
            pageBuilder: (context, state) => const CupertinoPage(child: HomeView()),
          ),
        ],
      ),


      GoRoute(
        path: playMusic,
        parentNavigatorKey: rootNavigatorKey,
        pageBuilder: (context, state) {
          final song = state.extra as Mp3FileModel;
          return CupertinoPage(
            child: PlayMusicView(song: song),
          );
        },
      ),

    ],
  );


  // Widget hiển thị khi sai Route
  static Widget _errorRoute(GoRouterState state) {
    return Scaffold(
      body: Center(
        child: Text(
          'Wrong Route provided ${state.uri}',
          style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w500),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }


  AppRoutes._();
}