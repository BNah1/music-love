class MockData {


  MockData._();
}
