import 'package:flutter/material.dart';

// Future<void> renamePlaylist() async {
//   final controller = TextEditingController();
//
//   await showDialog(
//     context: context,
//     builder: (toastContext) => AlertDialog(
//       title: const Text('Đổi tên playlist'),
//       content: TextField(
//         controller: controller,
//         decoration: const InputDecoration(
//           hintText: 'Tên playlist',
//         ),
//       ),
//       actions: [
//         TextButton(
//           onPressed: () => Navigator.pop(toastContext),
//           child: const Text('Hủy'),
//         ),
//         ElevatedButton(
//           onPressed: () async {
//             final name = controller.text.trim();
//             if (name.isEmpty) return;
//
//             // await ref.read(playlistProvider.notifier).createPlaylist(name);
//
//             if (toastContext.mounted) {
//               Navigator.pop(toastContext);
//             }
//           },
//           child: const Text('Đổi tên'),
//         ),
//       ],
//     ),
//   );
// }