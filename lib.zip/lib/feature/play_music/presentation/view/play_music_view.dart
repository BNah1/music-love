import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:musiclove/core/constant/app_enum.dart';
import 'package:musiclove/core/model/mp3_file_model.dart';
import 'package:musiclove/feature/play_music/presentation/view/widget/play_music_button_widget.dart';

class PlayMusicView extends StatefulWidget {
  final Mp3FileModel song;

  const PlayMusicView({super.key, required this.song});

  @override
  State<PlayMusicView> createState() => _PlayMusicViewState();
}

class _PlayMusicViewState extends State<PlayMusicView> with SingleTickerProviderStateMixin{
  late AudioPlayer _audioPlayer;
  late Size size;
  late AnimationController _animationController;


  PlayerState _playerState = PlayerState.stopped;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;

  @override
  void initState() {
    super.initState();

    // Khởi tạo controller xoay vô hạn
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 20), // 20 giây cho một vòng quay
    );

    _initAudioPlayer();
  }

  // Khởi tạo player và lắng nghe các thay đổi
  void _initAudioPlayer() {
    _audioPlayer = AudioPlayer();

    // Lắng nghe trạng thái (play/pause/stop)
    _audioPlayer.onPlayerStateChanged.listen((state) {
      if (state == PlayerState.playing) {
        _animationController.repeat();
      } else {
        _animationController.stop();
      }
      if (mounted) setState(() => _playerState = state);
    });

    // Lắng nghe tổng thời lượng bài hát
    _audioPlayer.onDurationChanged.listen((newDuration) {
      if (mounted) setState(() => _duration = newDuration);
    });

    // Lắng nghe tiến trình hiện tại
    _audioPlayer.onPositionChanged.listen((newPosition) {
      if (mounted) setState(() => _position = newPosition);
    });

    // Tự động phát khi vào view
    _playMusic();
  }

  @override
  void dispose() {
    _audioPlayer.dispose(); // Giải phóng bộ nhớ
    super.dispose();
  }

  Future<void> _playMusic() async {
    await _audioPlayer.play(DeviceFileSource(widget.song.path));
  }

  Future<void> _togglePlayPause() async {
    if (_playerState == PlayerState.playing) {
      await _audioPlayer.pause();
      _playerState = PlayerState.stopped;
      print('pause');
    } else {
      await _audioPlayer.resume();
      _playerState = PlayerState.playing;
      print('resumse');
    }
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.sizeOf(context);

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Container(
        width: double.infinity,
        decoration: _buildBackgroundDecoration(),
        child: Column(
          children: [
            const Spacer(),
            _buildAlbumArt(),
            const SizedBox(height: 40),
            _buildSongInfo(),
            const SizedBox(height: 30),
            _buildProgressBar(),
            const SizedBox(height: 20),
            _buildControlPanel(),
            const Spacer(flex: 2),
          ],
        ),
      ),
    );
  }

  // --- UI Components ---

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white, size: 35),
        onPressed: () => Navigator.pop(context),
      ),
      centerTitle: true,
      title: const Text(
        "ĐANG PHÁT",
        style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 2),
      ),
    );
  }

  BoxDecoration _buildBackgroundDecoration() {
    return const BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFFE0C3FC), Color(0xFF8EC5FC)],
      ),
    );
  }

  Widget _buildAlbumArt() {
    return RotationTransition(
      turns: _animationController,
      child: Container(
        width: size.width * 0.75,
        height: size.width * 0.75,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.2),
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white.withOpacity(0.3), width: 8),
        ),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(size.width),
            child: Container(
              color: const Color(0xFFFDFCF0),
              child: Icon(
                  Icons.music_note_rounded,
                  size: 100,
                  color: _playerState == PlayerState.playing ? Colors.pinkAccent : Colors.grey[400]
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSongInfo() {
    return Column(
      children: [
        Text(
          widget.song.title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        const SizedBox(height: 8),
        Text(
          widget.song.artist ?? '',
          style: const TextStyle(fontSize: 16, color: Colors.white70, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }

  Widget _buildProgressBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30),
      child: Column(
        children: [
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 4,
              activeTrackColor: Colors.white,
              inactiveTrackColor: Colors.white.withOpacity(0.3),
              thumbColor: Colors.white,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
            ),
            child: Slider(
              value: _position.inMilliseconds.toDouble(),
              max: _duration.inMilliseconds.toDouble() > 0 ? _duration.inMilliseconds.toDouble() : 1.0,
              onChanged: (value) async {
                await _audioPlayer.seek(Duration(milliseconds: value.toInt()));
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(_formatDuration(_position), style: const TextStyle(color: Colors.white70, fontSize: 12)),
                Text(_formatDuration(_duration), style: const TextStyle(color: Colors.white70, fontSize: 12)),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildControlPanel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.shuffle_rounded, color: Colors.white54, size: 24),
          const Spacer(),
          const PlayMusicButtonWidget(enumPlayMusic: EnumPlayMusic.back),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25),
            child: PlayMusicButtonWidget(
              onTap: _togglePlayPause,
              enumPlayMusic: _playerState == PlayerState.playing
                  ? EnumPlayMusic.pause
                  : EnumPlayMusic.play,
              isBigButton: true,
            ),
          ),
          const PlayMusicButtonWidget(enumPlayMusic: EnumPlayMusic.next),
          const Spacer(),
          const Icon(Icons.repeat_rounded, color: Colors.white54, size: 24),
        ],
      ),
    );
  }

  String _formatDuration(Duration duration) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');

    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);
    final seconds = duration.inSeconds.remainder(60);

    // Nếu có giờ thì hiển thị hh:mm:ss, ngược lại chỉ hiện mm:ss
    if (hours > 0) {
      return "${twoDigits(hours)}:${twoDigits(minutes)}:${twoDigits(seconds)}";
    }
    return "${twoDigits(minutes)}:${twoDigits(seconds)}";
  }
}