import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/constant/routes.dart';

class MainShellView extends StatelessWidget {
  const MainShellView({super.key, required this.child});
   final Widget child;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: child,
      bottomNavigationBar: _buildBottomNav(context),
    );
  }

  Widget _buildBottomNav(BuildContext context) {

    final String location = GoRouterState.of(context).uri.toString();
    int currentIndex = 0;
    if (location.startsWith(AppRoutes.playList)) currentIndex = 1;
    if (location.startsWith(AppRoutes.setting)) currentIndex = 2;

    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: (index) => _onItemTapped(index, context),
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: 'Dashboard'),
        BottomNavigationBarItem(icon: Icon(Icons.library_music_rounded), label: 'Playlist'),
        BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'Setting'),
      ],
    );
  }

  void _onItemTapped(int index, BuildContext context) {
    switch (index) {
      case 0: context.go(AppRoutes.home); break;
      case 1: context.go(AppRoutes.playList); break;
      case 2: context.go(AppRoutes.setting); break;
    }
  }

}